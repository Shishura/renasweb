const express = require('express');
const path = require('path')
const app = express();
const port = 3000;
const conexao = require('./conexao');
const tabelas = require('./tabelas');
const cors = require('cors');

tabelas.init(conexao);

app.use(express.urlencoded({ extended: true }))
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.use(cors());
app.use(express.json());

const ticketRoutes = require('./routes/ticketsRoutes');
const usuariosRoutes = require('./routes/usuariosRoutes');

app.use('/tickets', ticketRoutes);
app.use('/usuarios', usuariosRoutes);

app.listen(port, () => {
    console.log(`Servidor escutando na porta ${port}.`);
});