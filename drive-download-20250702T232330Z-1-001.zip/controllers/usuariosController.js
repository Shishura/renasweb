const usuarioModel = require('../models/usuario');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const jwtSecret = 'devwebtoken';

class UsuariosController {
    buscarTodosUsuarios(req, res) {
        const usuarios = usuarioModel.listarTodos();
        usuarios
            .then(usuarios => res.status(200).json(usuarios))
            .catch(err => res.status(400).json(err.message));
    }

    async criarNovoUsuario(req, res) {
        const { nome, email, senha } = req.body;
        const senhaCript = await bcrypt.hash(senha, 8);
        const novoUsuario = { nome: nome, email: email, senha: senhaCript };
        const usuarioSalvo = usuarioModel.criarUsuario(novoUsuario);
        usuarioSalvo
            .then(usuario => res.status(200).json(usuario))
            .catch(err => res.status(400).json(err.message));
    }

    efetuarLogin(req, res) {
        const { email, senha } = req.body;
        const usuario = { email: email, senha: senha };
        const login = usuarioModel.login(email);
        login
            .then(async (user) => {
                if (user == null) return res.status(404).send('Usuário não encontrado.');
                const isPasswordValid = await bcrypt.compare(senha, user.senha);
                if (!isPasswordValid) return res.status(401).send('Senha inválida.');

                const token = jwt.sign({ id: user.id }, jwtSecret, { expiresIn: '1h' });
                res.send({ auth: true, token });
            })
            .catch(err => res.status(400).json(err.message));
    }
}

module.exports = new UsuariosController();