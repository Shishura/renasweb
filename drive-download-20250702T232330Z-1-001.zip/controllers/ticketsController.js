const ticket = require('../models/ticket');
const ticketModel = require('../models/ticket');

class TicketsController {
    buscarTodosTickets(req, res) {
        const tickets = ticketModel.listarTodos(req.userId);
        tickets
            .then(tickets => res.status(200).json(tickets))
            .catch(err => res.status(400).json(err.message));
    }

    cadastrarTicket(req, res) {
        const { titulo, descricao, dataAbertura, resolvido } = req.body;
        const novoTicket = { titulo: titulo, descricao: descricao, dataAbertura: dataAbertura, resolvido: resolvido, userID: req.userId };
        const ticketSalvo = ticketModel.criarTicket(novoTicket);
        ticketSalvo
            .then(ticket => res.status(200).json(ticket))
            .catch(err => res.status(400).json(err.message));
    }
}

module.exports = new TicketsController();