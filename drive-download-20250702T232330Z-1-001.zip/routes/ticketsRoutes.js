const express = require('express');
const jwt = require('jsonwebtoken');
const ticketRoutes = express.Router();
const ticketsController = require('../controllers/ticketsController');
const jwtSecret = 'devwebtoken';

// Middleware para verificar o token JWT
const verifyToken = (req, res, next) => {
    const token = req.headers['x-access-token'];
    if (!token) return res.status(403).send('Token não fornecido.');

    jwt.verify(token, jwtSecret, (err, decoded) => {
        if (err) return res.status(500).send('Falha ao autenticar o token.');
        req.userId = decoded.id;
        next();
    });
};

ticketRoutes.get('/', verifyToken, ticketsController.buscarTodosTickets);
ticketRoutes.post('/register', verifyToken, ticketsController.cadastrarTicket);

module.exports = ticketRoutes;


//ticketRoutes.get('/:codigo', ticketsController.buscarTicketPorCodigo);
/**
 * 
 * app.get('/tickets', ticketController.listarTickets);
app.get('/tickets/:codigo', ticketController.buscarTicketPorCodigo);
app.post('/tickets/criarTicket', ticketController.criarTicket);
app.put('/tickets/atualizarTicket/:codigo', ticketController.atualizaTicketPorCodigo);
app.put('/tickets/resolverTicket/:codigo', ticketController.resolveTicketPorCodigo);
app.delete('/tickets/removerTicket/:codigo', ticketController.removeTicketPorCodigo);
 */

