const express = require('express');
const usuarioRoutes = express.Router();
const usuariosController = require('../controllers/usuariosController');

usuarioRoutes.get('/', usuariosController.buscarTodosUsuarios);
usuarioRoutes.post('/register', usuariosController.criarNovoUsuario);
usuarioRoutes.post('/login', usuariosController.efetuarLogin);

module.exports = usuarioRoutes;
