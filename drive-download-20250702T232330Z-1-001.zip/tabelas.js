class Tabelas{
    init(conexao){
        this.conexao = conexao;
        this.criarTabelaTickets();
        this.criarTabelaUsuarios();
    }

    criarTabelaTickets(){
        const sql = `
            CREATE TABLE IF NOT EXISTS tickets (
                codigo INT AUTO_INCREMENT PRIMARY KEY,
                titulo VARCHAR(255) NOT NULL,
                descricao TEXT NOT NULL,
                dataAbertura DATE NOT NULL,
                resolvido BOOLEAN NOT NULL,
                userID INT,
                FOREIGN KEY (userID) REFERENCES usuarios(id)
            );`;
        this.conexao.query(sql, (error) =>{
            if(error){ 
                console.log(error.message);
            }
            console.log('Tabela criada com sucesso!');
        });
    }

    criarTabelaUsuarios(){
        const sql = `
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                senha VARCHAR(255) NOT NULL
        );`;
        this.conexao.query(sql, (error) =>{
            if(error){ 
                console.log(error.message);
            }
            console.log('Tabela criada com sucesso!');
        });
    }
}
module.exports = new Tabelas();

