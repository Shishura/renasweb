const conexao = require('../conexao');

class Ticket {
    listarTodos(userID) {
        const sql = 'SELECT * FROM tickets WHERE userID = ?';
        //segundo parâmetro para where
        return new Promise((resolve, reject) => {
            conexao.query(sql, [userID], (error, resposta) => {
                if (error) {
                    console.log('Erro ao listar');
                    reject(error);
                }
                resolve(resposta);
            });
        });
    }

    criarTicket(ticket) {
        const { titulo, descricao, dataAbertura, resolvido, userID } = ticket;
        const sql = 'INSERT INTO tickets(titulo, descricao, dataAbertura, resolvido, userID) VALUES (?, ?, ?, ?, ?)';
        return new Promise((reject, resolve) => {
            conexao.query(sql, [titulo, descricao, dataAbertura, resolvido, userID], (error, resposta) => {
                if (error) {
                    console.log('Erro ao cadastrar');
                    reject(error);
                }
                resolve(resposta);
            });
        });
    }
}

module.exports = new Ticket();