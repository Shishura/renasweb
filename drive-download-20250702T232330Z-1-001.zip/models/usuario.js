const conexao = require('../conexao');

class Usuario{
    listarTodos(){
        const sql = 'SELECT * FROM usuarios';
        //segundo parâmetro para where
        return new Promise((resolve, reject) => {
            conexao.query(sql, {}, (error, resposta) =>{
                if (error){
                    console.log('Erro ao listar');
                    reject(error);
                }
                resolve(resposta);
            });
        });
    }

    criarUsuario(usuario) {
        const { nome, email, senha } = usuario;
        const sql = 'INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)';
        return new Promise((resolve, reject) => {
            conexao.query(sql, [nome, email, senha], (err, result) => {
                if (err) {
                    reject(err);
                } else {
                    resolve({ id: result.insertId, nome, email });
                }
            });
        });
    }

    login(email) {
        const sql = 'SELECT * FROM usuarios WHERE email = ?';
        return new Promise((resolve, reject) => {
            conexao.query(sql, [email], (err, results) => {
                if (err) {
                    reject(err);
                } else {
                    if (results.length === 0) {
                        resolve(null);
                    } else {
                        resolve(results[0]);
                    }
                }
            });
        });
    }
    
}

module.exports = new Usuario();

